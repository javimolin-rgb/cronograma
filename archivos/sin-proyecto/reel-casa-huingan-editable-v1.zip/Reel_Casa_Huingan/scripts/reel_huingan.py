#!/usr/bin/env python3
"""Reel / historia "Modelo de la semana" — Casa Huingán (mismo sistema que el reel de Casa Lingue).

Base: output/casa_huingan_secuencia.mp4 del repo javimolin-rgb/3d (rama javieramolin/eloquent-maxwell,
42 s, 720x1280, 24 fps): aproximación de dron en espiral desde la playa -> arco frontal (ventanales y
doble altura) -> costado -> sube a la cenital y se corta el techo -> planta de arquitectura en azul ->
vuelve a la cenital -> baja hacia el mar.

Una sola toma, sin cortes: solo rampas de velocidad (VELOCIDAD) y textos anclados al segundo de la
fuente (S_*), así siguen cayendo sobre lo que describen aunque cambie la velocidad.
La casa queda siempre bajo el bloque de texto (verificado segundo a segundo), por eso el encuadre
es el cuadro completo escalado a 1080x1920, sin recortes.

Uso:
  python3 reel_huingan.py                  # video sin audio -> salida/reel_huingan_mudo.mp4
  python3 reel_huingan.py --still 1.9 7    # cuadros sueltos (segundos de salida)
  python3 reel_huingan.py --guias 1.9      # con zona segura y tiempo de fuente
Datos: neorigen.cl/casa-huingan (2 dormitorios, 2 baños, 73,8 m² útiles, 37,9 m² terrazas, doble
altura de 2,20 a 6 m, estrategias sustentables). Planta: assets/planta_sin_cotas.pdf.
"""
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = Path(__file__).resolve().parent
A, F, OUT = HERE / "assets", HERE / "fuentes", HERE / "salida"
FUENTE = A / "casa_huingan_secuencia.mp4"
CACHE = HERE / ".cache_fuente.npy"
W, H, FPS = 1080, 1920, 30
SW, SH, SFPS = 720, 1280, 24
K = W / SW   # 1,5

AZUL, NIEBLA, PINO, MADERA, AMARILLO = (1, 30, 47), (241, 244, 243), (60, 74, 62), (169, 118, 74), (255, 237, 160)
MX, TXT_Y = 84, 262

COPY = {
    "b1": ("MODELO DE LA SEMANA", "Casa Huingán", "2 dormitorios y 2 baños, en un piso."),
    "b2": ("SUPERFICIE ÚTIL", "73,8 m²", "+ 37,9 m² de terrazas"),
    "b3": ("DOBLE ALTURA", "De 2,20 a 6 m", "Grandes ventanales termopanel, marco PVC"),
    "b4_label": "ESTRATEGIAS SUSTENTABLES",
    "b4": ["Fachada ventilada", "Sobre pilotes", "Aislación eficiente"],
    "b_dorm": ("1 PISO", "2 dormitorios", "Cada uno con su baño y clóset"),
    "b_estar": ("1 PISO", "Estar comedor", "Cocina integrada y lavadero"),
    "b_plan": "PLANTA DE ARQUITECTURA",
    "tabla": [("Superficie útil", "73,8 m²"), ("Terrazas", "37,9 m²"), ("Doble altura", "2,20 – 6 m")],
    "cierre": "Llave en mano",
    "cta": "COTIZA EN NEORIGEN.CL",
}

# ── tiempo: velocidad en función del segundo de la fuente ──────────────
VELOCIDAD = [(0.0, 1.15), (4.6, 1.15), (5.2, 1.0), (9.4, 1.0), (9.9, 0.9), (19.2, 0.9),
             (19.8, 1.7), (23.4, 1.7), (23.9, 0.8), (29.1, 0.8), (29.4, 1.0), (30.5, 1.0),
             (30.9, 0.4), (32.9, 0.4), (33.3, 1.0), (34.2, 1.0), (34.7, 1.6), (36.9, 1.6),
             (37.5, 0.74), (41.95, 0.6)]
S_FIN = 41.9


def gauss(a, sigma):
    if sigma <= 0:
        return a
    r = int(3 * sigma)
    k = np.exp(-0.5 * (np.arange(-r, r + 1) / sigma) ** 2)
    k /= k.sum()
    return np.convolve(np.pad(a, r, mode="edge"), k, mode="valid")


def build_timeline():
    ds = 1 / 240
    s = np.arange(0, S_FIN, ds)
    v = gauss(np.interp(s, *zip(*VELOCIDAD)), 0.3 / ds)
    t_out = np.concatenate([[0], np.cumsum(ds / v)[:-1]])
    n = int(t_out[-1] * FPS)
    return np.interp(np.arange(n) / FPS, t_out, s), t_out, s


SRC_T, _T_OUT, _S = build_timeline()
N = len(SRC_T)
DUR = N / FPS


def out_t(s):
    """Segundo de salida en que se ve el segundo s de la fuente."""
    return float(np.interp(s, _S, _T_OUT))


# ── fuente ─────────────────────────────────────────────────────────────
def load_video():
    if not CACHE.exists():
        raw = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", str(FUENTE), "-f", "rawvideo",
                              "-pix_fmt", "rgb24", "-"], capture_output=True, check=True).stdout
        np.save(CACHE, np.frombuffer(raw, np.uint8).reshape(-1, SH, SW, 3))
    return np.load(CACHE, mmap_mode="r")


VID = load_video()
LAST = len(VID) - 1
VEL = np.gradient(SRC_T) * SFPS


def src_frame(s, blur):
    f = s * SFPS
    n = int(blur * 2) + 1 if blur > 0.6 else 1
    fs = [f + blur * (i / (n - 1) - .5) for i in range(n)] if n > 1 else [f]
    acc = np.zeros((SH, SW, 3), np.float32)
    for x in fs:
        x = min(max(x, 0), LAST)
        i = int(x); u = x - i; j = min(i + 1, LAST)
        acc += VID[i] * (1 - u) + VID[j] * u
    return Image.fromarray((acc / len(fs)).astype(np.uint8))


def base_image(i):
    blur = max(0.0, VEL[i] - 0.9) * 1.3
    img = src_frame(SRC_T[i], blur).resize((W, H), Image.LANCZOS)
    return img.filter(ImageFilter.UnsharpMask(radius=2.0, percent=60, threshold=2))


# ── curvas ─────────────────────────────────────────────────────────────
def cl(x):
    return 0.0 if x < 0 else 1.0 if x > 1 else x


def p(t, a, b):
    return cl((t - a) / (b - a))


def out_expo(x):
    x = cl(x)
    return 1 if x == 1 else 1 - 2 ** (-10 * x)


def in_out(x):
    x = cl(x)
    return 4 * x ** 3 if x < .5 else 1 - (-2 * x + 2) ** 3 / 2


def in_cubic(x):
    return cl(x) ** 3


def out_back(x, s=1.6):
    x = cl(x) - 1
    return 1 + (s + 1) * x ** 3 + s * x ** 2


# ── tipografía ─────────────────────────────────────────────────────────
def font(name, size):
    return ImageFont.truetype(str(F / name), size)


FR = lambda s: font("FrauncesDisplay.ttf", s)
WS = lambda s: font("WorkSans-Regular.ttf", s)
WSM = lambda s: font("WorkSans-Medium.ttf", s)
MONO = lambda s: font("PlexMono-Medium.ttf", s)
F_LABEL, F_TITLE, F_SUB = MONO(30), FR(124), WS(40)
F_ROT = WSM(30)
LOGO = Image.open(A / "logo_blanco.png").convert("RGBA")


def line_img(text, f, fill):
    asc, desc = f.getmetrics()
    im = Image.new("RGBA", (int(f.getlength(text)) + 24, asc + desc + 16), (0, 0, 0, 0))
    ImageDraw.Draw(im).text((8, 8), text, font=f, fill=fill)
    return im


_cache = {}


def cached(text, f, key, fill=NIEBLA):
    if (text, key) not in _cache:
        _cache[(text, key)] = line_img(text, f, fill)
    return _cache[(text, key)]


def mask_line(canvas, im, x, y, e_in, e_out=0.0):
    """Línea que sube desde una máscara al entrar y sigue subiendo al salir."""
    if e_in <= 0 or e_out >= 1:
        return
    h = im.height
    top = int(round(y + (1 - e_in) * h - e_out * h))
    c0, c1 = max(0, int(y) - top), min(h, int(y + h) - top)
    if c1 > c0:
        canvas.alpha_composite(im.crop((0, c0, im.width, c1)), (int(x), top + c0))


Y_LABEL, Y_TITLE, Y_SUB = TXT_Y, TXT_Y + 44, TXT_Y + 202
Y_RULE = Y_SUB - 10


def rule(canvas, e, y=Y_RULE, x=MX, w=96):
    if e > 0:
        ImageDraw.Draw(canvas).rectangle((x, y, x + w * e, y + 5), fill=MADERA)


def block(canvas, t, s_in, s_out, label, title, sub, title_img=None, label_fijo=False):
    t_in, t_out = out_t(s_in), out_t(s_out)
    if not (t_in - .1 <= t < t_out + .6):
        return
    for k, (txt, f, key, y) in enumerate([(label, F_LABEL, "l", Y_LABEL), (title, F_TITLE, "t", Y_TITLE),
                                          (sub, F_SUB, "s", Y_SUB)]):
        if k == 0 and label_fijo:
            continue
        e_in = out_expo(p(t, t_in + k * .07, t_in + k * .07 + .65))
        e_out = in_cubic(p(t, t_out + k * .04, t_out + k * .04 + .32))
        im = title_img if (k == 1 and title_img is not None) else cached(txt, f, key)
        mask_line(canvas, im, MX - 8, y, e_in, e_out)
    if not label_fijo:
        rule(canvas, out_expo(p(t, t_in + .25, t_in + .8)) * (1 - in_out(p(t, t_out, t_out + .3))))


SCRIM = None


def scrim():
    global SCRIM
    if SCRIM is None:
        a = np.clip(1 - np.arange(H) / 860, 0, 1) ** 1.25 * 238
        s = np.zeros((H, W, 4), np.uint8); s[..., :3] = AZUL; s[..., 3] = a[:, None].astype(np.uint8)
        SCRIM = Image.fromarray(s, "RGBA")
    return SCRIM


GRAIN = [np.random.default_rng(i).normal(0, 3.0, (H // 2, W // 2)).astype(np.float32) for i in range(6)]


def grain(img, i):
    g = np.repeat(np.repeat(GRAIN[i % 6], 2, 0), 2, 1)[..., None]
    return Image.fromarray(np.clip(np.asarray(img, np.float32) + g, 0, 255).astype(np.uint8))


# ── anclas de texto, en segundos de la FUENTE ──────────────────────────
S_B1 = (0.2, 4.5)
S_B2 = (4.95, 9.3)
S_B3 = (9.8, 14.3)
S_SUST = (14.7, 19.35)
S_DORM = (24.0, 26.55)
S_ESTAR = (26.75, 29.15)
S_PLAN = (29.7, 32.7)   # sale antes de que la planta se funda a la cenital
S_CIERRE = 37.7

# ── rótulos de recintos sobre la cenital (px de la fuente, medidos en el segundo 26) ──
# nombre: (punto x, y), (lado de la etiqueta: -1 izq / 1 der, y de la etiqueta), grupo
ROTULOS = {
    "dorm": [("Dormitorio", (350, 478), (-1, 470)), ("Baño", (482, 428), (1, 405)),
             ("Dormitorio", (352, 806), (-1, 830)), ("Baño", (482, 852), (1, 875))],
    "estar": [("Estar", (300, 632), (-1, 640)), ("Cocina", (484, 640), (1, 640)),
              ("Lavadero", (487, 504), (1, 490)), ("Terraza", (205, 822), (-1, 905)),
              ("Porch", (530, 760), (1, 790))],
}
# los rótulos de dormitorios esperan a que la cámara termine de asentarse en la cenital
GRUPO_S = {"dorm": (25.15, S_DORM[1]), "estar": S_ESTAR}
# deriva leve de la cámara durante la cenital (px de la fuente, respecto del segundo 26)
DERIVA = [(23.9, (16, 8)), (24.5, (11, 8)), (25.0, (6, 5)), (26.0, (0, 0)), (27.0, (-4, -3)),
          (28.0, (-5, -5)), (30.0, (-5, -5))]


def deriva(s):
    ks = [k for k, _ in DERIVA]
    return (np.interp(s, ks, [d[0] for _, d in DERIVA]), np.interp(s, ks, [d[1] for _, d in DERIVA]))


def rotulo_img(text):
    key = ("rot", text)
    if key not in _cache:
        tw = int(F_ROT.getlength(text))
        asc, desc = F_ROT.getmetrics()
        im = Image.new("RGBA", (tw + 36, asc + desc + 20), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle((0, 0, im.width - 1, im.height - 1), radius=4, fill=AZUL + (240,))
        d.text((18, 9), text, font=F_ROT, fill=NIEBLA)
        _cache[key] = im
    return _cache[key]


def rotulos(canvas, t, s_now, grupo):
    s_in, s_out = GRUPO_S[grupo]
    a, b = out_t(s_in), out_t(s_out)
    if not (a <= t < b + .5):
        return
    dx, dy = deriva(s_now)
    d = ImageDraw.Draw(canvas)
    for k, (name, (px, py), (lado, ly)) in enumerate(ROTULOS[grupo]):
        e = out_expo(p(t, a + .35 + k * .11, a + .95 + k * .11))
        e *= 1 - in_out(p(t, b - .05 + k * .03, b + .3 + k * .03))
        if e <= 0.01:
            continue
        X, Y = (px - dx) * K, (py - dy) * K
        LY = (ly - dy) * K
        im = rotulo_img(name)
        ex = 44 if lado < 0 else W - 44 - im.width        # caja pegada al margen, lejos de la casa
        edge = ex + im.width if lado < 0 else ex
        # línea guía: punto -> codo a 45° -> borde de la etiqueta (se dibuja con el avance e)
        cx = X + np.sign(edge - X) * min(abs(LY - Y), abs(edge - X) * .6)
        pts = [(X, Y), (cx, LY), (edge, LY)]
        lens = [np.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]) for i in range(2)]
        L = sum(lens) * e
        cur = [pts[0]]
        for i in range(2):
            if L <= 0:
                break
            u = min(1, L / max(lens[i], 1e-6))
            cur.append((pts[i][0] + (pts[i + 1][0] - pts[i][0]) * u, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * u))
            L -= lens[i]
        alpha = int(255 * min(1, e * 1.6))
        d.line(cur, fill=AZUL + (alpha,), width=5, joint="curve")
        r = 13 * min(1, e * 1.8)
        d.ellipse((X - r - 4, Y - r - 4, X + r + 4, Y + r + 4), fill=NIEBLA + (alpha,))
        d.ellipse((X - r, Y - r, X + r, Y + r), fill=AZUL + (alpha,))
        ea = cl((e - .55) / .45)
        if ea > 0:
            box = im.copy()
            box.putalpha(box.getchannel("A").point(lambda v: int(v * ea)))
            canvas.alpha_composite(box, (int(ex + (-14 if lado < 0 else 14) * (1 - ea)), int(LY - im.height / 2)))


def tabla(canvas, t):
    a, b = out_t(S_PLAN[0]), out_t(S_PLAN[1])
    if not (a <= t < b + .6):
        return
    x0, x1, y0, row = 210, 870, 1418, 62
    d = ImageDraw.Draw(canvas)
    for k, (txt, val) in enumerate(COPY["tabla"]):
        ti = a + .45 + k * .12
        e_in, e_out = out_expo(p(t, ti, ti + .6)), in_cubic(p(t, b + k * .04, b + k * .04 + .32))
        y = y0 + k * row
        mask_line(canvas, cached(txt, WS(40), "tab"), x0 - 8, y, e_in, e_out)
        vi = cached(val, MONO(40), "tabv")
        mask_line(canvas, vi, x1 - vi.width + 8, y + 2, e_in, e_out)
        if k < len(COPY["tabla"]) - 1:
            e_r = out_expo(p(t, ti + .2, ti + .8)) * (1 - in_out(p(t, b, b + .3)))
            col = MADERA if k == 1 else (70, 96, 112)
            if e_r > 0:
                d.rectangle((x0, y + row - 2, x0 + (x1 - x0) * e_r, y + row - 2 + (3 if k == 1 else 1)), fill=col)


def overlay(img, t, s_now):
    img = img.convert("RGBA")
    img.alpha_composite(scrim())
    T = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    block(T, t, *S_B1, *COPY["b1"])
    t0 = out_t(S_B2[0])
    val = 73.8 * out_expo(p(t, t0 + .1, t0 + 1.2))
    title = f"{val:.1f}".replace(".", ",") + " m²"
    block(T, t, *S_B2, COPY["b2"][0], title, COPY["b2"][2], title_img=line_img(title, F_TITLE, NIEBLA))
    block(T, t, *S_B3, *COPY["b3"])
    # estrategias: rótulo fijo, titular que rota y contador 01/03
    a, b = out_t(S_SUST[0]), out_t(S_SUST[1])
    if a - .1 <= t < b + .6:
        mask_line(T, cached(COPY["b4_label"], F_LABEL, "l"), MX - 8, Y_LABEL, out_expo(p(t, a, a + .65)),
                  in_cubic(p(t, b, b + .32)))
        rule(T, out_expo(p(t, a + .25, a + .75)) * (1 - in_out(p(t, b, b + .3))))
        step = (b - a - .1) / 3
        for k, w in enumerate(COPY["b4"]):
            a0 = a + .1 + k * step
            b0 = a0 + step if k < 2 else b
            eo = in_cubic(p(t, b0, b0 + .3))
            mask_line(T, cached(w, F_TITLE, "t"), MX - 8, Y_TITLE, out_expo(p(t, a0, a0 + .6)), eo)
            mask_line(T, cached(f"0{k + 1} / 03", MONO(32), "n"), MX - 8, Y_SUB,
                      out_expo(p(t, a0 + .1, a0 + .6)), eo)
    # recintos: el rótulo "1 PISO" queda fijo entre los dos bloques
    a, b = out_t(S_DORM[0]), out_t(S_ESTAR[1])
    if a - .1 <= t < b + .6:
        mask_line(T, cached(COPY["b_dorm"][0], F_LABEL, "l"), MX - 8, Y_LABEL, out_expo(p(t, a, a + .65)),
                  in_cubic(p(t, b, b + .32)))
        rule(T, out_expo(p(t, a + .25, a + .8)) * (1 - in_out(p(t, b, b + .3))))
    block(T, t, *S_DORM, *COPY["b_dorm"], label_fijo=True)
    block(T, t, *S_ESTAR, *COPY["b_estar"], label_fijo=True)
    rotulos(T, t, s_now, "dorm")
    rotulos(T, t, s_now, "estar")
    # planta
    a, b = out_t(S_PLAN[0]), out_t(S_PLAN[1])
    if a - .1 <= t < b + .6:
        mask_line(T, cached(COPY["b_plan"], F_LABEL, "l"), MX - 8, Y_LABEL, out_expo(p(t, a, a + .65)),
                  in_cubic(p(t, b, b + .32)))
        rule(T, out_expo(p(t, a + .25, a + .8)) * (1 - in_out(p(t, b, b + .3))), y=Y_LABEL + 62)
    tabla(T, t)
    # cierre: logo, titular y CTA en la misma columna
    c = out_t(S_CIERRE)
    if t >= c:
        la = out_expo(p(t, c, c + .65))
        lw = 300
        lg = LOGO.resize((lw, round(LOGO.height * lw / LOGO.width)), Image.LANCZOS)
        lg.putalpha(lg.getchannel("A").point(lambda v: int(v * la)))
        T.alpha_composite(lg, (MX - 4, int(Y_LABEL - 6 + 20 * (1 - la))))
        y_t = Y_LABEL + lg.height + 22
        mask_line(T, cached(COPY["cierre"], F_TITLE, "t"), MX - 8, y_t, out_expo(p(t, c + .25, c + .95)))
        rule(T, out_expo(p(t, c + .55, c + 1.15)), y_t + 152)
        s = out_back(p(t, c + .95, c + 1.4))
        if s > .02:
            ci = line_img(COPY["cta"], MONO(34), AZUL)
            pw, ph = ci.width + 28, ci.height + 14
            pill = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
            ImageDraw.Draw(pill).rounded_rectangle((0, 0, pw - 1, ph - 1), radius=4, fill=AMARILLO)
            pill.alpha_composite(ci, (14, 7))
            sw, sh = max(1, int(pw * s)), max(1, int(ph * s))
            T.alpha_composite(pill.resize((sw, sh), Image.BICUBIC), (MX, int(y_t + 180 + (ph - sh) / 2)))
    img.alpha_composite(T)
    return img.convert("RGB")


def frame(i, guias=False):
    t = i / FPS
    img = overlay(base_image(i), t, SRC_T[i])
    if guias:
        d = ImageDraw.Draw(img)
        d.line((0, 250, W, 250), fill=(255, 220, 0), width=2)
        d.line((0, 1480, W, 1480), fill=(255, 220, 0), width=2)
        d.text((W - 260, 20), f"t={t:.2f} src={SRC_T[i]:.2f}", fill=(255, 255, 0))
    return grain(img, i)


def main():
    OUT.mkdir(exist_ok=True)
    print(f"duración: {DUR:.2f} s, {N} cuadros")
    for flag in ("--still", "--guias"):
        if flag in sys.argv:
            for v in sys.argv[sys.argv.index(flag) + 1:]:
                frame(min(N - 1, int(float(v) * FPS)), flag == "--guias").save(OUT / f"cuadro_{v}.png")
            return
    dst = OUT / "reel_huingan_mudo.mp4"
    ff = subprocess.Popen(["ffmpeg", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
                           "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-pix_fmt", "yuv420p",
                           "-profile:v", "high", "-movflags", "+faststart", str(dst)], stdin=subprocess.PIPE)
    for i in range(N):
        ff.stdin.write(frame(i).tobytes())
        if i % 90 == 0:
            print(f"{i}/{N}", flush=True)
    ff.stdin.close(); ff.wait()
    print("listo:", dst)


if __name__ == "__main__":
    main()
