#!/usr/bin/env python3
"""Voz en off del reel de Casa Huingán.

Herramienta: edge-tts (github.com/rany2/edge-tts), voces neuronales de Microsoft con acento real
de Chile, Perú y EE. UU. Cada frase se genera por separado y se ubica en el segundo del video que
le corresponde (anclada al tiempo de la FUENTE, igual que los textos de reel_huingan.py).

El texto en pantalla dice lo objetivo (datos); la voz dice lo emocional (para quién es, cómo se vive).

Uso:
  python3 voz_huingan.py                       # voz principal -> salida/voz_huingan.wav
  python3 voz_huingan.py --voz es-PE-CamilaNeural
  python3 voz_huingan.py --muestras            # todas las voces de VOCES -> salida/muestras_voz/
Requiere: pip install edge-tts, ffmpeg, numpy. Necesita internet.
"""
import asyncio
import hashlib
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np

sys_argv = sys.argv[:]
sys.argv = sys.argv[:1]
import reel_huingan as R  # noqa: E402

import edge_tts  # noqa: E402

SR = 48000
VOZ = "es-CL-CatalinaNeural"
VOCES = {   # voz: (velocidad, tono)
    "es-CL-CatalinaNeural": ("-6%", "-2Hz"),
    "es-CL-LorenzoNeural": ("-6%", "-2Hz"),
    "es-PE-CamilaNeural": ("-6%", "-2Hz"),
    "es-PE-AlexNeural": ("-6%", "-2Hz"),
    "es-US-PalomaNeural": ("-6%", "-2Hz"),
    "es-US-AlonsoNeural": ("-6%", "-2Hz"),
}

# (segundo de FUENTE donde empieza la frase, texto). "neorigen punto cl" se escribe como se dice.
GUION = [
    (0.75, "Hay casas pensadas para estar juntos, sin renunciar a tu propio espacio."),
    (6.0, "Amplia, luminosa, y toda en un solo nivel."),
    (10.2, "Adentro, el techo se eleva y la luz entra de lleno."),
    (15.4, "Pensada para cuidar su entorno… y a quienes la habitan."),
    (19.9, "Su planta mariposa lo cambia todo: un dormitorio en cada ala, y la vida en común al centro."),
    (26.9, "Ideal para dos parejas, para recibir a la familia, o a los amigos."),
    (30.9, "Cada uno con su privacidad. Y todos, alrededor de la misma mesa."),
    (36.4, "Casa Huingán. Para compartir lo que de verdad importa."),
    (39.9, "Cotízala en neorigen punto cl."),
]


async def tts(text, voz, rate, pitch, dst):
    await edge_tts.Communicate(text, voz, rate=rate, pitch=pitch).save(str(dst))


def decode(path):
    raw = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", str(path), "-f", "f32le", "-ac", "1",
                          "-ar", str(SR), "-"], capture_output=True, check=True).stdout
    x = np.frombuffer(raw, np.float32).copy()
    nz = np.flatnonzero(np.abs(x) > 0.004)            # recorta silencios del principio y el final
    return x[max(0, nz[0] - int(.02 * SR)):nz[-1] + int(.08 * SR)] if len(nz) else x


def build(voz, dst, tmp):
    rate, pitch = VOCES.get(voz, ("-6%", "-2Hz"))
    n = int((R.DUR + .3) * SR)
    out = np.zeros(n, np.float32)
    tramos = []
    for k, (s, text) in enumerate(GUION):
        mp3 = tmp / f"{voz}_{hashlib.md5((text + rate + pitch).encode()).hexdigest()[:10]}.mp3"
        for intento in range(5):           # el servicio a veces no responde: se reintenta
            if mp3.exists() and mp3.stat().st_size > 2000:
                break
            try:
                asyncio.run(tts(text, voz, rate, pitch, mp3))
            except Exception as e:
                print(f"  reintento {intento + 1} ({voz}, frase {k + 1}): {type(e).__name__}")
                mp3.unlink(missing_ok=True)
                import time; time.sleep(2 + 2 * intento)
        x = decode(mp3)
        t0 = max(R.out_t(s), tramos[-1][1] + .35) if tramos else R.out_t(s)   # nunca se pisan
        i = int(t0 * SR)
        x = x[:max(0, n - i)]
        out[i:i + len(x)] += x
        tramos.append((t0, t0 + len(x) / SR))
    # aviso si una frase pisa la siguiente
    for k in range(len(tramos) - 1):
        if tramos[k][1] > tramos[k + 1][0] - .15:
            print(f"  ! {voz}: la frase {k + 1} termina en {tramos[k][1]:.2f} s y la {k + 2} empieza en "
                  f"{tramos[k + 1][0]:.2f} s")
    out *= 10 ** (-3 / 20) / max(1e-9, np.abs(out).max())
    with wave.open(str(dst), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(out, -1, 1) * 32767).astype("<i2").tobytes())
    return tramos


def main():
    tmp = R.OUT / "tts_cache"
    tmp.mkdir(parents=True, exist_ok=True)
    if "--muestras" in sys_argv:
        d = R.OUT / "muestras_voz"
        d.mkdir(exist_ok=True)
        for v in VOCES:
            tr = build(v, d / f"voz_{v}.wav", tmp)
            print(v, " ".join(f"{a:.1f}-{b:.1f}" for a, b in tr))
        return
    voz = sys_argv[sys_argv.index("--voz") + 1] if "--voz" in sys_argv else VOZ
    tr = build(voz, R.OUT / "voz_huingan.wav", tmp)
    print(voz, " ".join(f"{a:.1f}-{b:.1f}" for a, b in tr))


if __name__ == "__main__":
    main()
