#!/usr/bin/env python3
"""Música, efectos y mezcla con voz en off del reel de Casa Huingán.

Es la misma música y los mismos efectos del reel de Casa Lingue (todo sintetizado aquí: sin
licencias de terceros), recalculados sobre la línea de tiempo de reel_huingan.py. Encima va la voz
en off (salida/voz_huingan.wav, de voz_huingan.py): la música baja sola mientras habla la voz.

La música es un loop cálido a 100 BPM en Re mayor (Dmaj9 - Bm9 - Gmaj9 - Asus2): pad, arpegio con
eco, bajo y percusión suave. Las secciones siguen al video: intro, entra el ritmo, se vacía en la
planta para leer tranquilo, vuelve con la bajada en espiral y cierra con el acorde final.
Los efectos se sincronizan con la línea de tiempo de reel_lingue.py: whoosh en los traslados
rápidos del dron, notas suaves cuando aparece cada recinto (afinadas con la música y paneadas
según el lado de la etiqueta), un toque al entrar cada texto y una campana en el CTA.

Uso: python3 audio_huingan.py   -> salida/audio_huingan.wav (mezcla) + salida/musica_efectos.wav (sin voz)
"""
import sys
import wave
from pathlib import Path

import numpy as np
from scipy import signal

sys_argv = sys.argv[:]
sys.argv = sys.argv[:1]
import reel_huingan as R  # noqa: E402  (línea de tiempo, anclas y rótulos)

SR = 48000
DUR = R.DUR + 0.2
N = int(DUR * SR)
BPM = 100
BEAT = 60 / BPM
BAR = 4 * BEAT
rng = np.random.default_rng(7)


def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def env_adsr(n, a, d, s, r, sr=SR):
    a, d, r = int(a * sr), int(d * sr), int(r * sr)
    e = np.full(n, s, np.float32)
    e[:a] = np.linspace(0, 1, a, endpoint=False) if a else 1
    e[a:a + d] = np.linspace(1, s, max(1, min(d, n - a)))[:max(0, min(d, n - a))]
    if r:
        e[-r:] *= np.linspace(1, 0, r)
    return e


def add(buf, x, t, pan=0.0, gain=1.0):
    """Suma x (mono o estéreo) en el segundo t, con paneo de potencia constante."""
    i = int(t * SR)
    if i >= len(buf) or i + len(x) <= 0:
        return
    if x.ndim == 1:
        th = (pan + 1) * np.pi / 4
        x = np.stack([x * np.cos(th), x * np.sin(th)], 1)
    j0 = max(0, -i)
    j1 = min(len(x), len(buf) - i)
    buf[i + j0:i + j1] += x[j0:j1] * gain


def lp(x, fc, order=2):
    sos = signal.butter(order, fc, "low", fs=SR, output="sos")
    return signal.sosfilt(sos, x, axis=0)


def hp(x, fc, order=2):
    sos = signal.butter(order, fc, "high", fs=SR, output="sos")
    return signal.sosfilt(sos, x, axis=0)


def bp(x, f0, f1, order=2):
    sos = signal.butter(order, [f0, f1], "band", fs=SR, output="sos")
    return signal.sosfilt(sos, x, axis=0)


# ── secciones (en compases desde t = 0) ────────────────────────────────
t_plan_in = R.out_t(29.4)
t_plan_out = R.out_t(33.8)
t_cierre = R.out_t(R.S_CIERRE)
bar_of = lambda t: int(t // BAR)
B_GROOVE = 1                                  # entra el ritmo en el compás 2
B_BREAK0 = bar_of(t_plan_in)                  # se vacía en la planta
B_BREAK1 = bar_of(t_plan_out) + 1             # vuelve después de la planta
B_OUTRO = bar_of(t_cierre) + (1 if t_cierre % BAR > BAR * .5 else 0)
NBARS = int(np.ceil(DUR / BAR)) + 1
print(f"compases: groove {B_GROOVE}, planta {B_BREAK0}-{B_BREAK1}, cierre {B_OUTRO}, total {NBARS}")

CHORDS = [  # (raíz del bajo, notas del pad, notas del arpegio)
    (38, [62, 66, 69, 73, 76], [74, 78, 81, 85, 81, 78]),       # Dmaj9
    (35, [59, 62, 66, 69, 73], [71, 74, 78, 81, 78, 74]),       # Bm9
    (31, [59, 62, 66, 67, 69], [67, 71, 74, 78, 74, 71]),       # Gmaj9
    (33, [57, 62, 64, 69, 71], [69, 74, 76, 81, 76, 74]),       # Asus2
]

music = np.zeros((N, 2), np.float32)
pad_bus = np.zeros((N, 2), np.float32)
arp_bus = np.zeros((N, 2), np.float32)
drum_bus = np.zeros((N, 2), np.float32)
bass_bus = np.zeros((N, 2), np.float32)
kick_env = np.zeros(N, np.float32)


def pad_note(f, dur):
    n = int(dur * SR)
    t = np.arange(n) / SR
    out = np.zeros((n, 2), np.float32)
    for ch, det in ((0, -0.11), (1, 0.13)):
        x = np.zeros(n)
        for h, a in ((1, 1.0), (2, 0.35), (3, 0.16), (4, 0.07)):
            for dd in (-1, 1):
                x += a * np.sin(2 * np.pi * f * h * (1 + dd * det / 100 * h) * t + rng.uniform(0, 6.28))
        out[:, ch] = x
    e = env_adsr(n, 0.9, 0.6, 0.75, 1.1)
    trem = 1 + 0.06 * np.sin(2 * np.pi * 0.25 * t)
    return (out * (e * trem)[:, None] * 0.05).astype(np.float32)


def pluck(f, dur=0.9, bright=1.0):
    n = int(dur * SR)
    t = np.arange(n) / SR
    x = np.sin(2 * np.pi * f * t) + 0.32 * bright * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t * 9)
    x += 0.12 * bright * np.sin(2 * np.pi * 3 * f * t) * np.exp(-t * 14)
    e = np.exp(-t * 5.5) * np.minimum(1, t / 0.004)
    return (x * e).astype(np.float32)


def kick(t0, g=1.0):
    n = int(0.45 * SR)
    t = np.arange(n) / SR
    f = 46 + 70 * np.exp(-t * 32)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 7.5)
    x += 0.15 * np.exp(-t * 300) * rng.standard_normal(n)       # leve ataque
    add(drum_bus, np.tanh(x * 1.4).astype(np.float32) * 0.55, t0, 0, g)
    i = int(t0 * SR)
    m = min(n, N - i)
    if m > 0:
        kick_env[i:i + m] = np.maximum(kick_env[i:i + m], np.exp(-t[:m] * 6))


def hat(t0, g=1.0, pan=0.2):
    n = int(0.09 * SR)
    t = np.arange(n) / SR
    x = hp(rng.standard_normal(n), 7000) * np.exp(-t * 55)
    add(drum_bus, x.astype(np.float32) * 0.09, t0, pan, g)


def snap(t0, g=1.0):
    n = int(0.22 * SR)
    t = np.arange(n) / SR
    x = bp(rng.standard_normal(n), 1400, 5200) * (np.exp(-t * 28) + 0.3 * np.exp(-t * 9))
    add(drum_bus, x.astype(np.float32) * 0.16, t0, -0.1, g)


for b in range(NBARS):
    t0 = b * BAR
    root, pad, arp = CHORDS[b % 4]
    breakdown = B_BREAK0 <= b < B_BREAK1
    outro = b >= B_OUTRO
    # pad (siempre; más presente en la planta y el cierre)
    pg = 1.25 if (breakdown or outro) else 1.0
    if not (outro and b > B_OUTRO):
        dur = BAR + (2.6 if outro else 0.6)
        for m in pad:
            add(pad_bus, pad_note(midi(m), dur), t0, 0, pg)
    elif b == B_OUTRO + 1:
        pass
    # arpegio en corcheas (6 notas que rotan), con dinámica
    if not (outro and b > B_OUTRO):
        for k in range(8):
            if outro and k >= 4:
                break
            if b == 0 and k < 2:
                continue
            m = arp[k % len(arp)] + (12 if (breakdown and k % 4 == 3) else 0)
            vel = (0.9 if k % 2 == 0 else 0.6) * (0.75 if breakdown else 1.0)
            pan = -0.45 if k % 2 == 0 else 0.45
            add(arp_bus, pluck(midi(m), bright=0.8 if breakdown else 1.0) * 0.11 * vel, t0 + k * BEAT / 2, pan)
    # bajo
    if B_GROOVE <= b < B_OUTRO and not breakdown:
        for off, ln in ((0, 1.3), (2.5 * BEAT, 0.9)):
            n = int(ln * SR)
            t = np.arange(n) / SR
            f = midi(root)
            x = np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * 2 * f * t)
            x = np.tanh(1.6 * x) * env_adsr(n, 0.01, 0.2, 0.7, 0.25)
            add(bass_bus, x.astype(np.float32) * 0.16, t0 + off, 0)
    # percusión
    if B_GROOVE <= b < B_OUTRO and not breakdown:
        full = b >= B_GROOVE + 1
        kick(t0)
        kick(t0 + 2 * BEAT, 0.9)
        if full and b % 2 == 1:
            kick(t0 + 3.5 * BEAT, 0.55)
        for k in range(8):
            if k % 2 == 1 or full:
                hat(t0 + k * BEAT / 2, (0.8 if k % 2 else 0.45) * (1 if full else 0.7), 0.25 if k % 2 else -0.15)
        if full:
            snap(t0 + BEAT); snap(t0 + 3 * BEAT, 0.9)
    if b == B_BREAK1 - 1:   # redoble suave de vuelta
        for k in range(4):
            hat(t0 + 3 * BEAT + k * BEAT / 4, 0.4 + 0.15 * k)
# acorde final largo en el cierre (Dmaj9 abierto) con fade
t_end = B_OUTRO * BAR + BAR
for m in (50, 57, 62, 66, 69, 76):
    add(pad_bus, pad_note(midi(m), max(1.0, DUR - t_end + 0.5)), t_end, 0, 0.9)


# ── efectos de mezcla de la música ──────────────────────────────────────
def delay_pingpong(x, t, fb=0.38, mix=0.32):
    d = int(t * SR)
    y = x.copy()
    for k in range(1, 6):
        g = mix * fb ** (k - 1)
        sh = np.zeros_like(x)
        if d * k < len(x):
            src = x[:-d * k] if k % 2 else x[:-d * k]
            sh[d * k:, 0 if k % 2 else 1] = src[:, 1 if k % 2 else 0] * g
            y += lp(sh, 4500)
    return y


def reverb(x, secs=2.4, mix=0.3):
    n = int(secs * SR)
    t = np.arange(n) / SR
    ir = rng.standard_normal((n, 2)) * np.exp(-t * 6.9 / secs)[:, None]
    ir = lp(ir, 5200)
    ir[:int(0.012 * SR)] *= 0.2
    wet = np.stack([signal.fftconvolve(x[:, c], ir[:, c])[:len(x)] for c in range(2)], 1)
    wet *= np.sqrt(np.mean(x ** 2) + 1e-12) / (np.sqrt(np.mean(wet ** 2)) + 1e-12)
    return x + wet * mix


duck = 1 - 0.32 * kick_env[:, None]
arp_bus = delay_pingpong(arp_bus, BEAT * 0.75)
music = reverb(pad_bus * duck, 3.0, 0.45) + reverb(arp_bus * duck, 2.2, 0.35) + \
    lp(bass_bus, 900) * duck + reverb(drum_bus, 1.2, 0.12)
# filtro que se cierra en la planta (sensación de pausa) y se abre al volver
tt = np.arange(N) / SR
closed = np.clip(np.minimum((tt - t_plan_in) / 1.2, (t_plan_out + 0.6 - tt) / 1.2), 0, 1)
music = music * (1 - closed[:, None]) + lp(music, 2200) * closed[:, None]

# ── efectos de sonido ───────────────────────────────────────────────────
sfx = np.zeros((N, 2), np.float32)


def whoosh(t_peak, dur=1.3, g=1.0, pan_from=-0.6, pan_to=0.6, hi=2600):
    n = int(dur * SR)
    t = np.arange(n) / SR
    noise = rng.standard_normal(n)
    bands = [(250, 700), (600, 1400), (1200, hi)]
    shape = np.exp(-((t - dur * 0.62) / (dur * 0.22)) ** 2)
    x = np.zeros(n)
    for k, (a, b) in enumerate(bands):
        w = np.clip(1 - abs(t / dur * 2.2 - (0.6 + k * 0.45)), 0, 1)
        x += bp(noise, a, b) * w
    x *= shape
    pan = np.linspace(pan_from, pan_to, n)
    th = (pan + 1) * np.pi / 4
    st = np.stack([x * np.cos(th), x * np.sin(th)], 1)
    add(sfx, (st * 0.22).astype(np.float32), t_peak - dur * 0.62, gain=g)


def tick(t0, g=1.0, f=2300, pan=-0.3):
    n = int(0.06 * SR)
    t = np.arange(n) / SR
    x = np.sin(2 * np.pi * f * t) * np.exp(-t * 90) + 0.3 * hp(rng.standard_normal(n), 4000) * np.exp(-t * 200)
    add(sfx, (x * 0.07).astype(np.float32), t0, pan, g)


def pop(t0, m, pan, g=1.0):
    n = int(0.5 * SR)
    t = np.arange(n) / SR
    f = midi(m) * (1 + 0.04 * np.exp(-t * 60))
    x = (np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.2 * np.sin(4 * np.pi * np.cumsum(f) / SR)) * np.exp(-t * 11)
    x *= np.minimum(1, t / 0.002)
    add(sfx, (x * 0.085).astype(np.float32), t0, pan, g)


def bell(t0, m, g=1.0):
    n = int(2.6 * SR)
    t = np.arange(n) / SR
    f = midi(m)
    x = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * d) for r, a, d in
            ((1, 1, 1.6), (2.0, 0.4, 2.4), (2.76, 0.28, 3.6), (5.4, 0.12, 6), (8.9, 0.05, 9)))
    add(sfx, (x * 0.07).astype(np.float32), t0, 0.1, g)


def swish(t0, g=1.0):
    n = int(0.35 * SR)
    t = np.arange(n) / SR
    x = hp(rng.standard_normal(n), 2500) * np.sin(np.pi * t / t[-1]) ** 2
    add(sfx, (x * 0.05).astype(np.float32), t0, 0.3, g)


# whooshes en los traslados rápidos (donde la velocidad sube sobre 1,6x)
vel = np.interp(np.arange(R.N), np.arange(R.N), np.gradient(R.SRC_T) * R.FPS)
fast = vel > 1.6
starts = [i for i in range(1, R.N) if fast[i] and not fast[i - 1]]
for k, i in enumerate(starts):
    j = i
    while j < R.N and fast[j]:
        j += 1
    whoosh((i + min(j - i, 30) * 0.5) / R.FPS, g=0.9, pan_from=(-0.6 if k % 2 == 0 else 0.6),
           pan_to=(0.6 if k % 2 == 0 else -0.6))
# planta: entra y sale como una hoja
swish(R.out_t(29.5), 1.2)
swish(R.out_t(33.7), 0.9)
# entrada de cada bloque de texto
for s_ in (R.S_B1[0], R.S_B2[0], R.S_B3[0], R.S_SUST[0], R.S_DORM[0], R.S_ESTAR[0], R.S_PLAN[0], R.S_CIERRE):
    tick(R.out_t(s_) + 0.05)
a_, b_ = R.out_t(R.S_SUST[0]), R.out_t(R.S_SUST[1])
for k in range(1, 3):
    tick(a_ + .1 + k * (b_ - a_ - .1) / 3 + 0.03, 0.7, 2600)
# rótulos de recintos: una nota de la escala por recinto, paneada según el lado de la etiqueta
ESCALA = [74, 76, 78, 81, 83, 86, 88, 90, 93, 95]   # Re mayor pentatónica
for g, grupo in enumerate(("dorm", "estar")):
    t0 = R.out_t(R.GRUPO_S[grupo][0])
    for k, (name, _, (lado, _)) in enumerate(R.ROTULOS[grupo]):
        pop(t0 + .35 + k * 0.11 + 0.3, ESCALA[k + g], 0.5 * lado, 0.9)
# tabla de superficies: tres notas suaves cuando aparece
tp = R.out_t(R.S_PLAN[0])
for k, m in enumerate((81, 86, 90)):
    pop(tp + .5 + k * 0.12, m, -0.3 + 0.3 * k, 0.8)
# CTA
bell(R.out_t(R.S_CIERRE) + 0.95, 86)
bell(R.out_t(R.S_CIERRE) + 0.95, 81, 0.5)

sfx = reverb(sfx, 1.6, 0.25)

# ── voz en off y master ────────────────────────────────────────────────
def leer_wav(path):
    with wave.open(str(path)) as w:
        x = np.frombuffer(w.readframes(w.getnframes()), "<i2").astype(np.float32) / 32768
        if w.getnchannels() == 2:
            x = x.reshape(-1, 2).mean(1)
    out = np.zeros(N, np.float32)
    out[:min(N, len(x))] = x[:N]
    return out


def compresor(x, umbral_db=-24, ratio=3.0, ataque=.005, suelta=.12):
    env = np.abs(x)
    a, r = np.exp(-1 / (ataque * SR)), np.exp(-1 / (suelta * SR))
    sm = signal.lfilter([1 - r], [1, -r], env)          # seguidor de envolvente (aprox.)
    sm = np.maximum(sm, signal.lfilter([1 - a], [1, -a], env))
    db = 20 * np.log10(sm + 1e-9)
    gain_db = np.minimum(0, (umbral_db - db) * (1 - 1 / ratio))
    return x * 10 ** (gain_db / 20)


VOZ_GAIN = 1.25
VOZ_WAV = Path(sys_argv[sys_argv.index("--voz") + 1]) if "--voz" in sys_argv else R.OUT / "voz_huingan.wav"
SALIDA = sys_argv[sys_argv.index("--salida") + 1] if "--salida" in sys_argv else "audio_huingan.wav"
voz = leer_wav(VOZ_WAV) if VOZ_WAV.exists() else np.zeros(N, np.float32)
voz = hp(voz, 85)
voz = voz + 0.35 * bp(voz, 2500, 6000)                 # presencia
voz = compresor(voz)
voz = voz / (np.sqrt(np.mean(voz[np.abs(voz) > 1e-4] ** 2)) + 1e-9) * 10 ** (-17 / 20)
voz_st = np.stack([voz, voz], 1)
voz_st = voz_st + 0.06 * (reverb(voz_st, 0.7, 1.0) - voz_st)   # un poco de sala, casi seca
# ducking: la música baja ~8 dB mientras habla la voz (con ataque y suelta suaves)
hab = (gauss_env := np.convolve((np.abs(voz) > 0.01).astype(np.float32), np.ones(int(.25 * SR)) / int(.25 * SR), "same"))
hab = np.clip(hab * 4, 0, 1)
hab = signal.lfilter([1 - np.exp(-1 / (.18 * SR))], [1, -np.exp(-1 / (.18 * SR))], hab)
duck_m = 10 ** (-6.5 * hab / 20)
duck_s = 10 ** (-3 * hab / 20)

fade_in = np.clip(tt / 0.4, 0, 1)
fade_out = np.clip((DUR - 0.1 - tt) / 2.2, 0, 1)


def master(mix, nombre):
    mix = hp(mix, 30) * (fade_in * fade_out)[:, None]
    mix *= 0.5 / max(1e-9, np.abs(mix).max())
    out = R.OUT / nombre
    with wave.open(str(out), "wb") as w:
        w.setnchannels(2); w.setsampwidth(4 // 2); w.setframerate(SR)
        w.writeframes((np.clip(mix, -1, 1) * 32767).astype("<i2").tobytes())
    print("listo:", out, f"{DUR:.2f} s")


master(music * 0.9 + sfx, "musica_efectos.wav")
lecho = 1.2 * (music * 0.9 * duck_m[:, None] + sfx * duck_s[:, None])
mezcla = lecho + voz_st * VOZ_GAIN
g = 0.5 / max(1e-9, np.abs(hp(mezcla, 30)).max())
master(mezcla, SALIDA)
if "--stems" in sys_argv:   # para revisar el balance: mismas ganancias que en la mezcla
    for x, nombre in ((lecho, "stem_lecho.wav"), (voz_st * VOZ_GAIN, "stem_voz.wav")):
        y = hp(x, 30) * (fade_in * fade_out)[:, None] * g
        with wave.open(str(R.OUT / nombre), "wb") as w:
            w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
            w.writeframes((np.clip(y, -1, 1) * 32767).astype("<i2").tobytes())
